
// Mobile nav
const toggle = document.querySelector('.nav-toggle');
const links = document.querySelector('.nav-links');
if (toggle) {
  toggle.addEventListener('click', () => {
    const open = links.style.display === 'flex';
    links.style.display = open ? 'none' : 'flex';
  });
}

// Browse filters
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const sizeFilter = document.getElementById('sizeFilter');
const clearBtn = document.getElementById('clearFilters');
const grid = document.getElementById('productGrid') || document;

function applyFilters(){
  const q = (searchInput?.value || '').toLowerCase();
  const cat = categoryFilter?.value || '';
  const size = sizeFilter?.value || '';
  const cards = grid.querySelectorAll('.card');
  cards.forEach(card => {
    const title = card.dataset.title?.toLowerCase() || '';
    const category = card.dataset.category || '';
    const sz = card.dataset.size || '';
    const matches = (!q || title.includes(q)) && (!cat || category === cat) && (!size || sz === size);
    card.style.display = matches ? '' : 'none';
  });
}

[searchInput, categoryFilter, sizeFilter].forEach(el => el && el.addEventListener('input', applyFilters));
clearBtn && clearBtn.addEventListener('click', () => {
  if (searchInput) searchInput.value = '';
  if (categoryFilter) categoryFilter.value = '';
  if (sizeFilter) sizeFilter.value = '';
  applyFilters();
});

// Rent buttons
document.querySelectorAll('.rent-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.dataset.item || 'Selected Outfit';
    alert(`${item} selected. Rent for 1 day + refundable deposit at pickup.`);
  });
});
